

import UIKit

extension Double {
  
  /// Rounds Double value
  func rounded(toPlaces places:Int) -> Double {
    let divisor = pow(10.0, Double(places))
    return (self * divisor).rounded() / divisor
  }
  
  /// Converts a double value into hours, minutes, and seconds
  func asString(style: DateComponentsFormatter.UnitsStyle) -> String {
    let formatter = DateComponentsFormatter()
    formatter.allowedUnits = [.hour, .minute, .second, .nanosecond]
    formatter.unitsStyle = style
    guard let formattedString = formatter.string(from: self) else { return "" }
    return formattedString
  }
}

let myFloat = 1.3589432
myFloat.rounded(toPlaces: 1)

var myOptionalDouble: Double?
myOptionalDouble = 3.987432
myOptionalDouble?.rounded(toPlaces: 2)
myOptionalDouble = nil
myOptionalDouble?.rounded(toPlaces: 2)



let elapsedSeconds: Double = 89032
elapsedSeconds.asString(style: .abbreviated)
elapsedSeconds.asString(style: .brief)
elapsedSeconds.asString(style: .full)
elapsedSeconds.asString(style: .positional)
elapsedSeconds.asString(style: .short)
elapsedSeconds.asString(style: .spellOut)


extension FloatingPoint {
  /// Determine if a Double or Float is an Int
  var isInt: Bool {
    return floor(self) == self
  }
}

let floatOne = 1.25
floatOne.isInt

let floatTwo = 1.00
floatTwo.isInt

extension String {

  /// Calculates the CGSize of a string
  func sizeOfString(usingFont font: UIFont) -> CGSize {
    let fontAttributes = [NSAttributedStringKey.font: font]
    let size = self.size(withAttributes: fontAttributes)
    return size
  }
  
  /// Calculates the width of a string as a CGFloat
  func widthOfString(usingFont font: UIFont) -> CGFloat {
    let fontAttributes = [NSAttributedStringKey.font: font]
    let size = self.size(withAttributes: fontAttributes)
    return size.width
  }
  
  /// Calculates the height of a string as a CGFloat
  func heightOfString(usingFont font: UIFont) -> CGFloat {
    let fontAttributes = [NSAttributedStringKey.font: font]
    let size = self.size(withAttributes: fontAttributes)
    return size.height
  }
}

let myLabel = UILabel()
myLabel.text = "Testing Testing 123"

myLabel.text?.sizeOfString(usingFont: UIFont.systemFont(ofSize: 12))
myLabel.text?.sizeOfString(usingFont: UIFont.systemFont(ofSize: 18))

myLabel.text?.widthOfString(usingFont: UIFont.systemFont(ofSize: 12))
myLabel.text?.widthOfString(usingFont: UIFont.systemFont(ofSize: 18))

myLabel.text?.heightOfString(usingFont: UIFont.systemFont(ofSize: 12))
myLabel.text?.heightOfString(usingFont: UIFont.systemFont(ofSize: 18))


